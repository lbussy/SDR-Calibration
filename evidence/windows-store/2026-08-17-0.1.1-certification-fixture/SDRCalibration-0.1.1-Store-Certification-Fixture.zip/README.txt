SDR Calibration Microsoft Store certification fixture

Synthetic recorded-input data only. No SDR hardware, RF observation, personal data, credential, or calibration-accuracy claim is present. Select request.json and trust.json in the GUI and choose a new output directory. The expected terminal state is success.
